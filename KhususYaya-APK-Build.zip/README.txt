KHUSUS YAYA - Android Prototype

Versi ini menggunakan Text-to-Speech bawaan Android.
Untuk membuat APK tanpa laptop:
1. Buat akun GitHub.
2. Buat repository baru.
3. Upload seluruh isi folder proyek ini.
4. Buka tab Actions.
5. Pilih "Build Khusus Yaya APK".
6. Tekan Run workflow.
7. Setelah selesai, buka hasil run dan download artifact "KhususYaya-debug-apk".
8. Extract ZIP artifact dan install app-debug.apk di HP.

Catatan:
- Suara Indonesia/English mengikuti mesin TTS yang tersedia di HP.
- Sunda hanya tersedia jika mesin TTS HP mendukungnya.
- Versi AI voice natural (creator, berita, curhat, review, dll.) memerlukan API voice AI dan akan dibuat pada tahap berikutnya.

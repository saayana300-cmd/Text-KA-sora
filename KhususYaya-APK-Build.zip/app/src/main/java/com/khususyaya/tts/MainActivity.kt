package com.khususyaya.tts

import android.app.Activity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var text: EditText
    private lateinit var speed: SeekBar
    private var ready = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
        }

        val title = TextView(this).apply {
            text = "Khusus Yaya"
            textSize = 28f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 20)
        }
        box.addView(title)

        text = EditText(this).apply {
            hint = "Tulis teks yang ingin dibacakan..."
            minLines = 7
            gravity = Gravity.TOP
        }
        box.addView(text, LinearLayout.LayoutParams(-1, 0, 1f))

        val lang = Spinner(this)
        val langs = arrayOf("Indonesia", "Sunda*", "English")
        lang.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, langs)
        box.addView(lang)

        val style = Spinner(this)
        val styles = arrayOf("Konten Kreator", "Pembawa Berita", "Curhat", "Puisi", "Review Produk", "Iklan", "Storytelling")
        style.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, styles)
        box.addView(style)

        val label = TextView(this).apply { text = "Kecepatan suara"; textSize = 16f }
        box.addView(label)
        speed = SeekBar(this).apply { max = 150; progress = 100 }
        box.addView(speed)

        val speak = Button(this).apply {
            text = "▶  Generate Voice"
            setOnClickListener { speak(lang.selectedItemPosition, style.selectedItemPosition) }
        }
        box.addView(speak)

        val stop = Button(this).apply {
            text = "■  Stop"
            setOnClickListener { tts.stop() }
        }
        box.addView(stop)

        val note = TextView(this).apply {
            text = "* Dukungan suara Sunda bergantung pada mesin TTS yang tersedia di HP."
            textSize = 12f
            setPadding(0, 12, 0, 0)
        }
        box.addView(note)

        setContentView(box)
    }

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (ready) tts.setSpeechRate(1.0f)
    }

    private fun speak(language: Int, style: Int) {
        if (!ready) return
        val raw = text.text.toString().trim()
        if (raw.isEmpty()) return
        val locale = when (language) {
            2 -> Locale.US
            else -> Locale("id", "ID")
        }
        val result = tts.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            Toast.makeText(this, "Bahasa tidak tersedia di mesin TTS HP ini.", Toast.LENGTH_LONG).show()
            return
        }
        val rate = 0.55f + (speed.progress / 100f) * 0.9f
        tts.setSpeechRate(rate)
        tts.setPitch(if (style == 3) 0.95f else 1.0f)
        tts.speak(raw, TextToSpeech.QUEUE_FLUSH, null, "khusus_yaya")
    }

    override fun onDestroy() {
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}
